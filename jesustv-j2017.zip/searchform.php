<div class="searchbar">
	<form name="search" method="get" action="<?php bloginfo('url'); ?>/">
		<input type="text" class="cuadro_input" name="s" value="" placeholder="escribe lo que buscas">		
		<button type="submit"><span class="icon-search fa  fa-search"></span></button>
	</form>	
</div>